var count = 9;
var counterElement = document.querySelector("#count");

console.log(counterElement);

function add1()
{
    count++;
    counterElement.innerText = count +  "like(s)";
    console.log(count);
}

var count1 = 12;
var counterElement1 = document.querySelector("#count1");

console.log(counterElement1);

function add12()
{
    count1++;
    counterElement1.innerText = count1 +  "like(s)";
    console.log(count1);
}

var count3 = 9;
var counterElement3 = document.querySelector("#count3");

console.log(counterElement3);

function add13()
{
    count3++;
    counterElement3.innerText = count3 +  "like(s)";
    console.log(count3);
}