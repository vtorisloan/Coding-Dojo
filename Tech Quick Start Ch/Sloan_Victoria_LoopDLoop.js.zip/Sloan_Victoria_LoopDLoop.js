for (var miles = 0; miles < 6; miles+=2){
    console.log("candy")
}
