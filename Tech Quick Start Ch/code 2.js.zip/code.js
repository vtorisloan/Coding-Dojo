export function main() {
    function greeting(){
        return "Hello World";
    }
    var word = greeting();
    console.log();
}
export function main() {
    function greeting(){
        return "Hello World";
    }
    var word = greeting();
    console.log(word); //adding 'word' into the consol.log prints the greeting
}
