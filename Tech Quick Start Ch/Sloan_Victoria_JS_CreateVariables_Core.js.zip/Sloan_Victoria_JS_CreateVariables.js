var height = 41
var age = 10
if (height => 42){
    console.log("Get on that ride, kiddo!")
}
else if (age => 10) {
    console.log("Get on that ride, kiddo!")
}
else {
    console.log("Sorry kiddo. Maybe next year!")
}















