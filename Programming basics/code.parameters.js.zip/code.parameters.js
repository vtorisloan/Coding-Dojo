export function main() {
    function greet(Jedi){
    if (Jedi == "Anakin"){
console.log("Good Afternoon, Anakin!");
}
    else {
        console.log("I'm coming for you, Dooku!")
}
}
greet("Anakin")
greet("Count Dooku");
}
